import json
import mimetypes
import os
import re
import time
from shutil import copyfile
from wsgiref.util import FileWrapper

from django.http import JsonResponse, HttpResponseRedirect, StreamingHttpResponse

from video_summary_website.settings import MEDIA_ROOT

result_now = None

COMMAND_FILEPATH = '../command.txt'
RESULT_FILEPATH = '../result.txt'
UPLOAD_VIDEO_FILEPATH = '../videos/%s.mp4'


# Create your views here.
def index(request):
    return HttpResponseRedirect('/static/index.html?videosrc=%s'%request.GET.get('videosrc',''))


def load_result_from_file():
    with open(RESULT_FILEPATH, 'r') as f:
        result = f.read()
    global result_now

    if result_now == result:
        return None

    result_now = result
    return result if not result.startswith('RESULT:') else json.loads(result[7:])


def put(request):
    result = load_result_from_file()
    result_type = result is None or type(result) == str

    if not result_type:
        img_dir = 'static/imgs/'
        for copyed_img_file in [x for x in os.listdir(img_dir) if x.startswith('cp_')]:
            os.remove(os.path.join(img_dir, copyed_img_file))

        now_path = []
        for filepath, score in result:
            path = os.path.join(img_dir, 'cp_' + os.path.split(filepath)[-1])
            now_path.append(['/' + path, score])
            copyfile(filepath, path) 
        result = now_path
    return JsonResponse(data={'data': result, 'type': result_type})


def uploadfile(request):
    if request.method == 'POST':
        file = request.FILES.get('video_file')
        query = request.POST.get('query')
        with open(UPLOAD_VIDEO_FILEPATH % query, 'wb') as f:
            for ck in file.chunks():
                f.write(ck)
                f.flush()

        with open(COMMAND_FILEPATH, 'w') as f:
            f.write('#'.join([str(time.time()), query]))
        return HttpResponseRedirect('/?videosrc=%s'%query)


def file_iterator(file_name, chunk_size=8192, offset=0, length=None):
    with open(file_name, "rb") as f:
        f.seek(offset, os.SEEK_SET)
        remaining = length
        while True:
            bytes_length = chunk_size if remaining is None else min(remaining, chunk_size)
            data = f.read(bytes_length)
            if not data:
                break
            if remaining:
                remaining -= len(data)
            yield data


def media(request, path):
    path = os.path.join(MEDIA_ROOT, path)
    """将视频文件以流媒体的方式响应"""
    range_header = request.META.get('HTTP_RANGE', '').strip()
    range_re = re.compile(r'bytes\s*=\s*(\d+)\s*-\s*(\d*)', re.I)
    range_match = range_re.match(range_header)
    size = os.path.getsize(path)
    content_type, encoding = mimetypes.guess_type(path)
    content_type = content_type or 'application/octet-stream'
    if range_match:
        first_byte, last_byte = range_match.groups()
        first_byte = int(first_byte) if first_byte else 0
        last_byte = first_byte + 1024 * 1024 * 2  # 2M 每片,响应体最大体积
        if last_byte >= size:
            last_byte = size - 1
        length = last_byte - first_byte + 1
        resp = StreamingHttpResponse(file_iterator(path, offset=first_byte, length=length), status=206,
                                     content_type=content_type)
        resp['Content-Length'] = str(length)
        resp['Content-Range'] = 'bytes %s-%s/%s' % (first_byte, last_byte, size)
    else:
        # 不是以视频流方式的获取时，以生成器方式返回整个文件，节省内存
        resp = StreamingHttpResponse(FileWrapper(open(path, 'rb')), content_type=content_type)
        resp['Content-Length'] = str(size)
    resp['Accept-Ranges'] = 'bytes'
    return resp


result_now = load_result_from_file()
