from django.urls import path

import App.views

urlpatterns = [
    path('', App.views.index, name='index'),
    path('put/', App.views.put, name='put'),
    path('uploadfile/', App.views.uploadfile, name='uploadfile'),
]
